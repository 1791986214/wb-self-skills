---
name: design-systems
description: "三套原生 Web 设计体系（透镜 Lens / 点阵 Lattice / 序曲 Overture）的选型与取用手册。当用户要做有质感的网页、要「像某个设计系统那样的风格」、要玻璃拟态/点阵粒子/摄影歌剧院这类视觉语言，或问「用什么设计体系」「参考哪套组件库」「把这些组件搬进来」时加载。技能内不含上游 168MB 源码，首次使用靠 bin/skillup.py update 拉取到本机缓存。\n\n【中文触发词】设计体系、设计系统、Lens、Lattice、Overture、玻璃拟态、点阵粒子、序曲、组件风格、参考哪套设计"
---

# 三套原生 Web 设计体系 · 选型与取用

来源：[ruiqichenbiec/design-systems](https://github.com/ruiqichenbiec/design-systems)（MIT，2026-10-04 快照）
展示站：https://ruiqichenbiec.github.io/design-systems/

这三套不是「组件库」，是**三套完整的设计语言**：每套都有自己的材质规律、运动原语和组件准入标准，
展示站上每一屏都是体系自己的实时渲染。取用的正确姿势是**理解它的规律再写组件**，
而不是把 HTML 拷过来改文字——拷过来会立刻露馅。

## 先拉上游（第一次必做）

本技能**不镜像**上游源码：整个仓库 168MB，其中序曲一套就 124MB（照片、字体、宣传片、three.js 副本）。
镜像进来会让技能包失去可分发性和平台上传资格。

```bash
python3 <技能目录>/bin/skillup.py update    # 克隆/拉取上游到 ~/.cache/wb-skill-cache/
python3 <技能目录>/bin/skillup.py status    # 看当前锁定提交与缓存路径
```

拉完后上游就在 `~/.cache/wb-skill-cache/ruiqichenbiec__design-systems/`，
本地起站点预览：`cd 该目录 && node serve.mjs` → http://127.0.0.1:4300/

> 单文件展示页可以直接双击打开，不需要服务端。ES module 组件目录必须走 HTTP。

## 怎么选：三套体系的分工

| | 体系 | 视觉语言 | 底层 | 组件数 | 什么时候用它 |
|---|---|---|---|---|---|
| 01 | **透镜 Lens** | 玻璃承载信息，液体表达连续变化，光表达状态 | WebGL2，零运行时依赖 | 18 类 | 要做**高级感仪表盘 / 数据面板 / 金融或 SaaS 产品站**，需要实时折射与弹性手感 |
| 02 | **点阵 Lattice** | 万物皆点集，交互即映射 | three.js + WebGL2 | 14 类 | 要做**个人网站 / 品牌首页 / 需要记忆点的开场**，能接受 WebGL 与深色夜场 |
| 03 | **序曲 Overture** | 摄影、歌剧、时装；光圈开幕、显影、弹簧共振 | WebGPU / WebGL2 | 46 类 | 要做**品牌官网 / 作品集 / 时尚或影像类产品**，重氛围、重动效叙事 |

选型口诀：
- 要**可信、克制、能承载表格和图表** → 透镜（它的 18 个组件都架在同一块透镜上，最像「能上生产」的一套）
- 要**一眼记住、可以玩** → 点阵
- 要**讲故事、有情绪** → 序曲
- 三者都要**深色**才成立；往浅色主题硬套会崩，别试。

## 三套的运动原语（这是灵魂，别绕开）

- **透镜**：弹簧形变 + 实时折射 + 原创合成音。玻璃不是装饰，是**承载层**；状态变化用光表达，不用颜色硬切。
- **点阵**：交互 = 从一个点集到另一个点集的**映射**。列表变网格不是位移动画，是点集重排；指针经过是场扰动。
- **序曲**：三个原语驱动全部 46 个组件——开幕 `iris()`（以触发点为圆心的光圈）、显影 `develop()`、共振 `spring()`。
  五档预设：snap 340ms / settle 570ms / stage 830ms / resonance 0.53s / swing 1.05s。
  **改组件时复用这五档，不要自己写新的时长。**

## 取用的三条路径

### 路径 A：整包引入（推荐，最省事）

**透镜**有明确的可复用包：`lens/lab/design-system/`——18 类组件、13 种原创音效、连续摩擦音、
CSS/JSON 变量、TypeScript 类型、双语活目录。直接把整个目录拷进项目静态资源即可，运行时零依赖。

```bash
cp -R ~/.cache/wb-skill-cache/ruiqichenbiec__design-systems/lens/lab/design-system <你的项目>/vendor/lens
```

**序曲**：`dist/` 自带运行时、样式、字体、照片、three.js、GPU 引擎，可单独拷走。

### 路径 B：单文件嵌入（做演示页、单页交付物）

三套都有单文件展示页，内含全部运行代码：

- `lens/lens-showcase-standalone.html`（18 类组件 + 双语 + 材质实验室）
- `lattice/dist/lattice-showcase.html`（659KB，three.js 已打包）
- `overture/dist/overture-showcase.html`（6.6MB，含字体照片与 720p 宣传片）

单文件适合**照着看规律**，或直接当落地页骨架改。改的时候先读该体系的 `DESIGN.md`。

### 路径 C：只借语言，自己写（长期项目）

读这三份，把规律抄进自己的设计令牌，然后用自己项目的组件实现：

- `lens/lab/design-system/DESIGN.md` + `SCOPE.md`（核心元素、透镜承载、反馈方式、组件准入）
- `lattice/DESIGN.md` + `lattice/VERIFICATION.md`
- `overture/DESIGN.md` + `overture/MOTION-SPEC.md`

这是最不容易翻车的路径：**只借材质与运动规律，不借代码**。

## 硬约束（踩了就白做）

1. **动态默认全开**，三套都假设完整动效。做无障碍适配时才降到 `prefers-reduced-motion`，别默认关。
2. **必须真机验证 WebGL**。透镜要 WebGL2；序曲先试 WebGPU、回退 WebGL2；点阵是 WebGL2 + three.js。
   在无 GPU 的环境（CI、老虚拟机）里会直接黑屏——要有降级方案。
3. **字体大多走 Google Fonts**，内网/离线环境要自带字体，否则排版会崩。
4. **透镜的折射只采样体系自己的画布**，不能拿去折射任意 DOM 或第三方页面。
5. **序曲的示例照片和参考图是 AI 生成**的，商用要自己换图。
6. 上游**已停止维护**（README 明说 issues 可能不回）。当静态参考资料用，别指望修 bug。

## 落地验收清单

- [ ] 选定体系，并写出「为什么是它」一句话
- [ ] 运动时长/曲线取自该体系预设，不是自己拍的
- [ ] 深色底、语义色没有偏离该体系令牌
- [ ] WebGL 等级检测 + 降级路径
- [ ] 字体本地化（离线可打开）
- [ ] 极端数据下不塌（长名称、空列表、超大数字）
- [ ] 减少动态偏好下可用
