# 上游状态（自动生成，勿手改）

本技能不镜像上游内容，只在本机缓存一份完整仓库供查阅与取用。

| 项 | 值 |
|---|---|
| 仓库 | `ruiqichenbiec/design-systems` |
| 分支 | `main` |
| 提交 | `7a424c9` |
| 本地缓存 | `/Users/lang/.cache/wb-skill-cache/ruiqichenbiec__design-systems` |
| 更新时间 | 2026-10-21 16:06 |

## 缓存目录构成

| 路径 | 文件数 | 体积 |
|---|---|---|
| `LICENSE` | 1 | 1.0 KB |
| `README.md` | 1 | 5.0 KB |
| `ds-viewer/` | 5 | 45.8 KB |
| `exposure/` | 6 | 71.5 KB |
| `index.html` | 1 | 48.5 KB |
| `lattice/` | 122 | 2.3 MB |
| `lens/` | 87 | 2.2 MB |
| `overture/` | 341 | 122.9 MB |
| `serve.mjs` | 1 | 2.5 KB |
