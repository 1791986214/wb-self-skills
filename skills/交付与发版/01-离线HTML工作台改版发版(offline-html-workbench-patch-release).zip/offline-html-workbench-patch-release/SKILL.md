---
name: offline-html-workbench-patch-release
description: 给「单文件离线 HTML 工作台 + Python 启动器 + 云端更新源」这类交付物做小改并安全发版的完整链路——二进制补丁保 CRLF、抽 script 块做语法回归、CDP 真实浏览器验证、版本号递增重打包、生成发版载荷并公网回读。触发词：改工作台、工作台.html、拿钱工具、离线 HTML 交付、发版到云端、更新源、拆包即用。
agent_created: true
---

# 离线 HTML 工作台：小改 + 安全发版

**适用**：一个 1 MB 级、内嵌全部数据的单文件 HTML，由本地 Python 启动器托管，同时存在「云端更新源 + 静态托管」两个落点，老客户端会按 sha1/版本号自动更新。

**核心风险**：改错行尾会毁包；改完不发版＝改了白改（会被老客户端降级覆盖）；只比 sha1 不比版本号的更新逻辑会把本地新版本覆盖回旧版。

---

## 铁律（先记住这四条）

1. **二进制读写**。这类 HTML 是 Windows 打包产物、全文 CRLF。用文本模式写回会把 N 个 CRLF 变成 LF，凭空少 N 字节。补丁脚本必须 `io.open(P,'rb')` 读、`'wb'` 写，插入内容显式写 `\r\n`。
2. **版本号唯一来源是 `version.txt`**。改内容必递增；不改版本号则老客户端不会更新。发版脚本一律从 `version.txt` 读版本，不要在代码里硬编码 `v18`。
3. **报完成前必须回读**。云端上传后用公网 URL 逐件下载比对字节数与 sha1；本地包要 `zip.read()` 与源文件逐字节比。
4. **公网/本地请求一律 `--noproxy '*'`** 并先 `unset http_proxy https_proxy all_proxy HTTP_PROXY HTTPS_PROXY ALL_PROXY`（本机有代理时否则 502）。

---

## 五步链路

### 1. 先取证，再改（别猜）

真实浏览器打开、切到目标视图、截图 + 读出目标元素的 `offsetHeight`，确认「用户看到的到底是哪个元素」。本次大哥说「不要显示当前模式的 gui」，实测发现是 `#modelBar` 里标题为「当前模型」的 552px 高卡。

### 2. 二进制单点补丁

写 `patch_v<NN>.py`，模式固定：

```python
raw = io.open(P,'rb').read()
assert raw.count(b'\r\n') > 2000 and raw.count(b'\n') == raw.count(b'\r\n'), '源文件不是纯 CRLF，停手'
OLD_B, NEW_B = OLD.encode('utf8'), NEW.encode('utf8')
assert raw.count(OLD_B) == 1, '锚点不唯一'      # 唯一性断言，比行号稳
out = raw.replace(OLD_B, NEW_B, 1)
assert out.count(b'\n') == out.count(b'\r\n')   # 写回后不能有裸 LF
assert OLD_B not in out and NEW_B in out
io.open(P,'wb').write(out)
```

- **优先用「唯一字符串」做锚点，不要用行号**（行号会漂移；老脚本用行号是因为要一次打 23 处）。
- 改前先 `cp` 一份 `<name>.html.v<NN>.bak` 当回滚料；打包脚本要把 `*.bak` 全部排除。

### 3. 语法回归（改 HTML 最容易把 JS 改坏）

抽出所有内联 `<script>` 块，逐块交给 `node --check`：

```python
blocks = re.findall(r'<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>', html, re.S)
# 每块写临时 .js → subprocess.run([NODE, '--check', f])  → returncode 必须全 0
```

### 4. CDP 真实浏览器验证（不要用内置浏览器自动化）

Node 22 内建全局 `WebSocket`，直连 Chrome DevTools Protocol，零外部依赖：
`/json/list` 拿 page 的 `webSocketDebuggerUrl` → `Page.enable` / `Runtime.enable`。
Chrome for Testing 必须带 `--no-sandbox --disable-setuid-sandbox --disable-dev-shm-usage --disable-gpu --allow-file-access-from-files`（缺 `--no-sandbox` 会 `Page.enable` 超时）。

验证要覆盖：**每个视图的显隐/内容** + **改动的边界用例**（如「在概览上切模型后卡仍隐藏」「切到 t1 后卡出现」）+ **页面 JS 异常数必须为 0**。
`file://` 与 `http://127.0.0.1:<port>` 两种形态各跑一遍——启动器会往页面注入 `window.CLOUD`，两种形态的行为不一定相同。

### 5. 重打包 → 生成发版载荷 → 上传 → 公网回读

```bash
printf '19' > dev/<app>/version.txt          # 递增版本
python3 gen_package.py                        # 读 version.txt，产出 out/<app>_v19.zip + dist/
python3 gen_release.py                        # 产出 release_v19/{5 件 + latest.json + publish_manifest.json}
```

- `gen_release.py` 必须交叉校验「**包内三件 == 载荷三件**」，否则「拉差异件」和「下整包」的用户会拿到不同代码。
- 上传次序：内容件先、`latest.json` **最后**（避免「指针先行、文件未到」的半截状态）。
- 落点两个（本项目的）：① 更新源前缀 `ai-money-workbench/` ② 静态托管根 `/`。第三个落点是项目资产▸软件分发（属于项目资产写入，**须先经用户确认**）。
- 上传后公网回读：`latest.json` 的 version + 三个内容件的字节数与 sha1 + zip 的体积与 sha1。

---

## 更新逻辑的坑（务必保留版本守卫）

只比 sha1 的更新检查会把「本地已经修好的新版本」误判成「需要更新」，于是把本地修复整份覆盖回云端旧版 —— 这是**交付阻断级** bug。正确写法是**版本号单向守卫**：

```python
if latest_ver <= out['current']:
    out['skipped'] = True; out['ok'] = True
    print('当前版本 %s ≥ 云端版本 %s —— 本地更新，跳过（绝不降级覆盖）' % (out['current'], latest_ver))
    return out
```

发版后实跑一次 `launcher.py --check-update`，确认输出「当前版本 N ≥ 云端版本 N —— 本地更新，跳过」。

---

## CDP 脚本自身的坑

- **`eval()` 外层包了 `(function(){ ... })()`**，所以表达式里必须**自己写 `return`**。直接塞一个 IIFE `(()=>{...})()` 会被当语句执行掉、静默返回 `undefined` —— 我已经踩过两次。
- 复用脚本时旧 Chrome profile 残留会报 `ENOTEMPTY`：先 `pkill -f remote-debugging-port=<port>`，再换新 profile 目录。
- 在 `<textarea>` 里清空输入：`End` 键只到当前行行尾 → 用 `setSelectionRange(len, len)` + 逐字符 Backspace。
- 无头模式更脆弱（Meta+A 失效、被 SIGTERM）→ 用**有头**模式跑探针。
- **断言失败先怀疑用例**：本次测「切模型」时把表名写成 `03-税率表`（真名 `07-税率表`），下拉回落空值走了 `|| '默认值'` 兜底，看起来像「切换没生效」，其实是脚本错。

---

## 拆包即用验证（交付物可用性的唯一凭据）

光验开发目录不算交付。必须：解压交付包 → 用包内启动器起服务 → 真实浏览器跑一遍核心功能（本项目 `cdp_smoke.mjs`，20 项）。本次 v19 拆包冒烟 20/20 通过。

---

## 本项目速查（拿钱工具工作台）

| 项 | 值 |
|---|---|
| 工作副本 | `<ws>/work/dev/拿钱工具工作台/` |
| 工作台本体 | `工作台.html`（v19 = 1,040,255 B / 2773 行 CRLF / sha1 `e8de002b31d5`） |
| 启动器 | `launcher.py`（47,899 B / sha1 `3e182e4b02c1`），默认端口 8788 |
| 版本号 | `version.txt`（当前 19） |
| 关键锚点 | `const SHEETS = [...]`（内嵌 11 表）· `renderModelBar()` · `vSolve()` · `renderVerify()` · `renderHomeDeliver()` |
| 已有脚本 | `patch_v19.py` · `gen_package.py` · `gen_release.py` · `gen_memory_v19.py` · `cdp_lib.mjs` · `cdp_v19_check.mjs` · `cdp_numeric.mjs` · `cdp_smoke.mjs` · `cdp_e2e.mjs` |
| 落点① | `https://ai-money-workbench-qilexiang123-d2ginduff8a522bfa.webapps.tcloudbase.com`（前缀 `ai-money-workbench/`） |
| 落点② | `https://qilexiang123-d2ginduff8a522bfa-1470806321.tcloudbaseapp.com`（根） |
| 落点③ | 项目资产▸软件分发（tdrive，**须用户确认**）；自 v18 起一直未同步，仍是 v16 |
| 项目记忆正本 | 项目资产《项目记忆_薪酬体系线.md》，**追加制**，每次会话必须追加，禁止新建散文件 |

**记忆追加姿势**：下载云端正本 → 本地 `base.rstrip('\n') + '\n' + ADD` → 展示给用户 → 确认后同名覆盖上传 → 下载回读 md5 比对。

---

## 结构校验（archinorm 框架图）—— 2026-10-09 新增

改完 HTML / launcher 之后，除功能回归外还要同步**结构数据**，否则框架图会与代码脱节。
技能已于 2026-10-09 由 normify 升级为 **archinorm v1.2.0**（深色交互式框架图：节点链路 + 依赖曲线 + 语义着色 + 下钻面板）。

**落点（薪酬体系线工作区）**

| 项 | 值 |
|---|---|
| 内部细图结构数据 | `work/archinorm-workbench/`（55 模块 / 43 叶子 / 73 API / 深 4 层） |
| 内部框架图 | `work/archinorm-workbench/architecture.html`（103,040 B，深色） |
| 对外粗图 | `work/archinorm-workbench-public/`（14 模块）+ 同名 `architecture.html`（42,864 B） |
| 引擎 | `~/.workbuddy/skills/archinorm/bin/run.sh` |
| 架构规则 | `archinorm-workbench/policy.yml`（5 条：acyclic / forbid-dependency / layer-direction / naming / max-depth） |
| 旧版留档 | `work/_old_normify_backup/`（normify-* 已弃用，仅存档） |

**发版后固定动作**（本项目**不是 git 仓库**，不要用 `sync`，会报 `refresh/git-unavailable`）

```sh
SK=~/.workbuddy/skills/archinorm/bin/run.sh
$SK validate --dir work/archinorm-workbench --repo work        # 有 error 必修；warning 记录不阻断
$SK patch --dir work/archinorm-workbench --id <改动所在模块> --repo work   # 刷新 fingerprint
$SK build --dir work/archinorm-workbench --repo work --render  # 重出图
```

⚠️ 调 `run.sh` 时**别把 stderr 合并进 stdout**（`2>&1`）：启动器每天一次的静默版本自检会把 JSON 写进 stderr，混进来会破坏 JSON 解析。用 `2>/dev/null`。

**注意**
- 模块 `source` 用「文件 + 行区间」锚定；HTML 行号一变锚点就漂 → 改版后必须 `patch --repo` 刷新 fingerprint，必要时修 `line/end_line`。
- 只改 `工作台.html` 时受影响的是 `workbench.frontend.*`；改 `launcher.py` 时是 `workbench.server.*`。
- 铁律：**只读业务代码**。结构数据全部落在 `archinorm-*/`，业务源码零改动（交付时用 sha1 前后比对存证）。
- 引擎可自我更新：`python ~/.workbuddy/skills/archinorm/bin/skillup.py status|check|update`（失败自动回滚，旧版一律改名备份、绝不删除）。
