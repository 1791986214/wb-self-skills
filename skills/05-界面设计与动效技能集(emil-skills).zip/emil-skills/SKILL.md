---
name: emil-skills
description: "界面设计与动效判断的完整技能集（15 个子技能）。当要做动效、评审动效、修掉帧、选 UI 库、判断界面哪里不够精致、让网页在手机上像原生、用极端数据压测界面时加载。含：设计总纲、动效构建、动效评审、动效改造、动效机会、动效性能、动效词汇、Apple 设计原则、UI 库选型、多版原型、网页像原生、UI 压测、Sonner 通知、Expo 动效、Swift 写法。源自 Emil Kowalski 在 Vercel / Linear 的实战经验。中文触发词：动效、动画、界面设计、设计判断、UI 品味、评审动效、掉帧卡顿、缓动曲线、100vh、安全区、toast、选库、原型对比、压测界面。"
---

# 界面设计与动效技能集（15 个子技能）

上游：[emilkowalski/skills](https://github.com/emilkowalski/skills)（MIT）· 作者 Emil Kowalski（Vercel / Linear）
**一个完整包，15 个子技能全部在里面**，不要当成 15 个独立技能去找。

## 先读这一页，再读子技能

本页只是**路由表**，真正的规则在子技能里。按任务打开对应文件，不要凭印象编：

```
skills/<子技能目录>/SKILL.md     ← 正文
skills/<子技能目录>/附带文档.md   ← 配方、标准、模板
```

例：要做入场动画 → 读 `skills/animate/SKILL.md` 与 `skills/animate/RECIPES.md`。

## 15 个子技能

| 子技能 | 什么时候用 | 附带文档 |
|---|---|---|
| `emil-design-eng` | **总纲**。拿不准先读它：阴影与边框、层级、什么时候不该加东西 | — |
| `animate` | 从零做一个动效：先定该不该动，再定属性、曲线、时长、中断、退出 | `RECIPES.md` |
| `review-animations` | 已有动效逐条挑毛病，说出哪条不合格、为什么 | `STANDARDS.md` |
| `improve-animations` | 扫全库动效，出分级可执行的改造计划 | `AUDIT.md`、`PLAN-TEMPLATE.md` |
| `find-animation-opportunities` | 判断界面哪里值得加动效、哪里加了反而糟 | — |
| `animation-performance` | 掉帧、卡顿、滚动发涩：合成层、布局抖动、transform/opacity | — |
| `animation-vocabulary` | 把「就是那种感觉」翻译成准确术语，好跟人或 AI 说清 | — |
| `apple-design` | Apple 的界面与流体动效原则，翻译成 Web 可落地的做法 | — |
| `pick-ui-library` | 选库别手搓、别装弃坑包 | — |
| `prototype` | 一个 UI 一次出几版，带切换器对比挑一个 | `PICKER.md` |
| `mobile-native` | 让网页在手机上像 App：hover 粘滞、点击高亮、100vh、输入框缩放、安全区 | — |
| `break-ui` | 用最坏数据撑坏界面：超长名字、空列表、超大数字 | `CATALOG.md` |
| `ask-sonner` | Sonner toast 的安装、样式、配方、常见问题 | `API.md` |
| `animate-expo` | React Native / Expo：手势、弹层、触感、转场、移出 JS 线程 | `RECIPES.md` |
| `write-swift` | 现代 Swift：值类型、Swift 6 并发、泛型、性能、Swift Testing | — |

## 这套东西的共同判断链

15 个子技能其实共用一条链子，记住它就不会乱：

1. **该不该动** —— 动效服务于「状态变化可被理解」，不是装饰。纯装饰的动效是噪音。
2. **目的是什么** —— 提示来源、提示去向、提示因果、还是拖时间？目的不清就别做。
3. **用哪个工具** —— CSS transition / keyframes / spring 库 / Web Animations，按是否可中断选。
4. **动哪些属性** —— 只动 `transform` 和 `opacity`；动 layout 属性必然掉帧。
5. **曲线与时长** —— 进场 `ease-out`，退场 `ease-in`，位移大就短，别用默认值。
6. **怎么被中断** —— 用户中途反向操作时，从当前姿态接着走，不要跳回起点。
7. **怎么退出** —— 退出通常比进入快，且方向要一致。

## 三条最容易踩的

- **`ease-in` 用于进场是错的**。进场要「快起慢收」= `ease-out`；`ease-in` 是给离场用的。
- **不要用实线边框表达层次**，用半透明阴影。实线边框会把界面压扁。
- **不要给所有东西都加动效**。`find-animation-opportunities` 有一半篇幅在讲**不该加**的地方。

## 更新

```bash
python3 bin/skillup.py check     # 查上游新提交
python3 bin/skillup.py update    # 拉取并替换 skills/ 下的 15 个子技能
python3 bin/skillup.py status    # 看锁定的源与提交
```

`update` 只覆盖 `skills/` 子目录，本页 SKILL.md 与 `bin/` 不会被冲掉。

## 与其它技能的分工

- 要做**具体某个网页的视觉语言**（液态玻璃、点阵、摄影歌剧）→ 用 `design-systems`
- 要做**动效短片 / 产品宣传片** → 用 `onetake`
- 本包管的是**界面层面**的判断与手法，不产出视频、不产出设计体系。
