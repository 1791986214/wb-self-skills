#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
scan_project.py — 项目地图扫描器（project-map-skill 的配套脚本）

用途
----
首次装好 project-map-skill 后跑一次，为**当前项目**生成一份
`<项目根>/.workbuddy/PROJECT-MAP.md`，把项目特有的东西固化下来
（目录结构、记忆文件、资产盘根 id、常用命令、技能清单），
免得每个新会话都重新扫一遍项目。

安全边界（硬约束）
------------------
* **只读项目**：只做 os.scandir / 读文本，从不修改、移动、删除项目内任何文件。
* **只写一个文件**：唯一写动作是输出 `PROJECT-MAP.md`，且**必须落在项目根目录内**
  （越界直接拒绝退出）。
* **零网络**：不 import socket / urllib / requests / subprocess，不联网、不起进程。
* **零第三方依赖**：仅用 Python 标准库，Python 3.9+ 可跑。

用法
----
    python scripts/scan_project.py                      # 扫当前目录
    python scripts/scan_project.py --root /path/to/proj
    python scripts/scan_project.py --tdrive-root CbtGrAtxbZgjpuzlFBsx --tdrive-name p_xxx
    python scripts/scan_project.py --depth 3 --no-skills
    python scripts/scan_project.py --print              # 只打印到 stdout，不写文件

退出码：0 成功 / 2 参数或越界错误。
"""

from __future__ import annotations

import argparse
import datetime as _dt
import json
import os
import re
import sys
from pathlib import Path

# ----------------------------------------------------------------------------
# 常量：扫描时忽略的目录 / 文件（噪音源，扫了没用还拖慢）
# ----------------------------------------------------------------------------
SKIP_DIRS = {
    ".git", ".svn", ".hg", "node_modules", "__pycache__", ".venv", "venv",
    ".idea", ".vscode", ".mypy_cache", ".pytest_cache", ".ruff_cache",
    "dist", "build", ".next", ".cache", "tmp", ".tmp", "site-packages",
    ".DS_Store",
}

# 记忆文件所在的相对目录
MEMORY_DIR_REL = os.path.join(".workbuddy", "memory")

# 输出文件名
OUT_REL = os.path.join(".workbuddy", "PROJECT-MAP.md")

# 常见命令入口探测
COMMAND_HINTS = ("Makefile", "makefile", "justfile", "Taskfile.yml", "docker-compose.yml")
SHELL_EXT = (".sh", ".bash", ".zsh", ".command")
PY_EXT = (".py",)


def _is_skipped(name: str) -> bool:
    return name in SKIP_DIRS or name.startswith(".modify_backup")


def _tree(root: Path, depth: int, max_entries: int = 40) -> list[str]:
    """产出 markdown 列表形式的目录树（限深、限宽，避免长成几千行）。"""
    lines: list[str] = []

    def walk(cur: Path, level: int, prefix: str) -> None:
        if level > depth:
            return
        try:
            entries = sorted(
                os.scandir(cur), key=lambda e: (not e.is_dir(), e.name.lower())
            )
        except (PermissionError, OSError):
            return
        shown = 0
        for e in entries:
            if _is_skipped(e.name):
                continue
            if shown >= max_entries:
                lines.append(f"{prefix}- …（其余条目已省略）")
                return
            shown += 1
            try:
                is_dir = e.is_dir()
            except OSError:
                continue
            if is_dir:
                lines.append(f"{prefix}- `{e.name}/`")
                walk(Path(e.path), level + 1, prefix + "  ")
            else:
                try:
                    size = e.stat().st_size
                except OSError:
                    size = 0
                lines.append(f"{prefix}- `{e.name}` ({_human(size)})")

    walk(root, 1, "")
    return lines


def _human(size: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024.0
    return f"{size:.1f} GB"


def _memory_section(root: Path) -> list[str]:
    """记忆文件区：列出 MEMORY.md 与最近几篇日志。"""
    out: list[str] = []
    mem_dir = root / MEMORY_DIR_REL
    if not mem_dir.is_dir():
        out.append("- （暂无 `.workbuddy/memory/` 目录）")
        return out

    long_term = mem_dir / "MEMORY.md"
    if long_term.is_file():
        try:
            chars = len(long_term.read_text(encoding="utf-8", errors="replace"))
        except OSError:
            chars = 0
        out.append(f"- `MEMORY.md`（长期记忆，约 {chars} 字符）")
    else:
        out.append("- `MEMORY.md`（尚未建立）")

    logs = sorted(
        (p for p in mem_dir.glob("*.md") if re.fullmatch(r"\d{4}-\d{2}-\d{2}\.md", p.name)),
        reverse=True,
    )
    if logs:
        latest = logs[:3]
        head = "最近 3 篇" if len(logs) > 3 else "最近"
        out.append(f"- 当日日志：{len(logs)} 篇，{head} —— " +
                   "、".join(f"`{p.name}`" for p in latest))
    else:
        out.append("- 当日日志：暂无")
    return out


def _commands_section(root: Path) -> list[str]:
    """常用命令区：从已知清单/脚本目录里挑，不做任何执行。"""
    out: list[str] = []

    pkg = root / "package.json"
    if pkg.is_file():
        try:
            data = json.loads(pkg.read_text(encoding="utf-8", errors="replace"))
            scripts = data.get("scripts") or {}
            if scripts:
                out.append("- **npm scripts**：" + "、".join(f"`{k}`" for k in list(scripts)[:10]))
        except (OSError, ValueError):
            pass

    for name in COMMAND_HINTS:
        if (root / name).is_file():
            out.append(f"- 构建/任务入口：`{name}`")

    for sub in ("scripts", "tools", "bin", "work"):
        d = root / sub
        if not d.is_dir():
            continue
        try:
            files = sorted(
                e.name for e in os.scandir(d)
                if e.is_file() and (e.name.endswith(SHELL_EXT + PY_EXT))
            )
        except OSError:
            continue
        if files:
            out.append(f"- `{sub}/` 下可执行脚本（{len(files)} 个）：" +
                       "、".join(f"`{f}`" for f in files[:8]) +
                       ("…" if len(files) > 8 else ""))
    if not out:
        out.append("- （未探测到常见命令入口）")
    return out


def _skills_section(no_skills: bool) -> list[str]:
    """技能清单区：列用户级 + 项目级技能名（只看目录名，不读内容）。"""
    if no_skills:
        return ["- （已按 --no-skills 跳过）"]
    out: list[str] = []
    # 与 SKILL.md 的说明保持一致，不做任何联网/远程解析。
    for label, path in (("用户级", Path.home() / ".workbuddy" / "skills"),):
        if path.is_dir():
            try:
                names = sorted(e.name for e in os.scandir(path) if e.is_dir())
            except OSError:
                names = []
            out.append(f"- {label}（`{path}`）：" +
                       ("、".join(f"`{n}`" for n in names) if names else "无"))
    if not out:
        out.append("- （未探测到技能目录）")
    return out


def build(root: Path, tdrive_root: str, tdrive_name: str, depth: int, no_skills: bool) -> str:
    """拼出完整的 PROJECT-MAP.md 文本。"""
    now = _dt.datetime.now().strftime("%Y-%m-%d %H:%M")
    lines: list[str] = []
    lines.append("# PROJECT-MAP · 项目地图速查")
    lines.append("")
    lines.append(f"> 由 `project-map-skill/scripts/scan_project.py` 于 {now} 自动生成（只读扫描）。")
    lines.append("> 新会话先读本文件 + `project-map-skill` 技能，**不要重新扫描项目**。")
    lines.append("")

    lines.append("## 0. 项目根")
    lines.append("")
    lines.append(f"- 路径：`{root}`")
    lines.append("")

    lines.append("## 1. 资产盘（tdrive）")
    lines.append("")
    if tdrive_root:
        lines.append(f"- 项目盘根 dir_name：`{tdrive_name or '(未提供)'}`")
        lines.append(f"- 项目盘根 root_dir_id：`{tdrive_root}`")
    else:
        lines.append("- ⚠️ 未提供项目盘根 id。补法：看会话上下文里的 `<tdrive-root id=\"…\" />`，"
                     "然后重跑 `--tdrive-root <id>`；或直接在当前会话用 `tdrive.dir_list` 现查。")
    lines.append("- 读写优先级：**先原生 `tdrive.*`**，报 401 credential fetch failed / "
                 "not found in the deferred tools index 时，才走技能 `project-cloud-assets-skill` 兜底。")
    lines.append("")

    lines.append(f"## 2. 目录结构（深度 {depth}）")
    lines.append("")
    lines.extend(_tree(root, depth) or ["- （空目录）"])
    lines.append("")

    lines.append("## 3. 记忆文件")
    lines.append("")
    lines.extend(_memory_section(root))
    lines.append("")

    lines.append("## 4. 常用命令")
    lines.append("")
    lines.extend(_commands_section(root))
    lines.append("")

    lines.append("## 5. 已装技能")
    lines.append("")
    lines.extend(_skills_section(no_skills))
    lines.append("")
    lines.append("---")
    lines.append("_本文件为快照，内容变了就重跑 `python scripts/scan_project.py`。_")
    lines.append("")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="只读扫描当前项目，生成 .workbuddy/PROJECT-MAP.md（项目地图速查）。"
    )
    ap.add_argument("--root", default=".", help="项目根目录，默认当前目录")
    ap.add_argument("--out", default=None, help="输出路径，默认 <root>/.workbuddy/PROJECT-MAP.md")
    ap.add_argument("--tdrive-root", default="", help="项目盘根 root_dir_id（来自会话上下文）")
    ap.add_argument("--tdrive-name", default="", help="项目盘根 dir_name（可选，便于人读）")
    ap.add_argument("--depth", type=int, default=2, help="目录树深度，默认 2")
    ap.add_argument("--no-skills", action="store_true", help="跳过技能目录扫描")
    ap.add_argument("--print", dest="to_stdout", action="store_true", help="只打印，不写文件")
    args = ap.parse_args(argv)

    root = Path(args.root).expanduser().resolve()
    if not root.is_dir():
        print(f"[scan_project] 项目根不存在或不是目录：{root}", file=sys.stderr)
        return 2

    text = build(root, args.tdrive_root.strip(), args.tdrive_name.strip(),
                 max(0, args.depth), args.no_skills)

    if args.to_stdout:
        print(text)
        return 0

    out = Path(args.out).expanduser().resolve() if args.out else (root / OUT_REL)

    # 安全闸门：输出必须落在项目根目录内，否则拒绝写入。
    try:
        out.relative_to(root)
    except ValueError:
        print(f"[scan_project] 拒绝写入项目目录之外：{out}", file=sys.stderr)
        return 2

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text, encoding="utf-8")
    print(f"[scan_project] 已生成 {out}（{len(text)} 字符，只读扫描，未改动任何项目文件）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
