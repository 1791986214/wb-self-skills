# archinorm 生成器作业手册（GENERATOR）

> 本手册是上游 [yan-mc/dsh-normify](https://github.com/yan-mc/dsh-normify) 的 `normify-gen` 技能在 archinorm 上的对等物。
> `SKILL.md` 教你怎么**调命令**；本手册教你怎么**产出合格的结构数据**——两者缺一不可。
> 命令名一律用 archinorm 的：`upsert` / `batch` / `patch` / `refresh` / `layout-upsert` / `validate` / `build` / `render` …
> 完整字段规范见 `SPEC.md`，速查见 `help fields` / `help deps` / `help renders`。

---

## 0. 铁律（生成器视角）

1. **产物是"可读的图"，不是"一堆框"**：接口（apis）在叶子上，逻辑（deps 箭头）把它们连起来，
   箭头上的流动动效把逻辑演出来。**没有 API、没有箭头的产出是无效产出。**
2. **只读源码**：绝不改被分析仓库的一行代码；结构数据只写进 `archinorm-<slug>/`。
3. **规模与深度都不设上限**：真实项目常见 **100–1000+ 模块**。宁可多建框，也不要把多个职责
   合并成一个粗框。**轮次与 token 预算不是提前收尾的理由**——分批多次提交就是了。
4. **增量优于全量**：代码变了只重建受影响子树，但每次增量后全项目仍须 0 error。
5. **拿到代码就提取**：每个叶子都要**从代码里**把 API 提全（路由/RPC/事件/表/队列/文件），
   每个模块都要**从调用点**把出向依赖提全。不是"想写就写、想省就省"。
6. **不臆造**：只写能从代码/文档确认的 API 与依赖；不确定的用 `reference` kind 或干脆不写。
   参数与语义拿不准就留空并标注待审，不编。
7. **计划优先**：先建计划态树（`state=planned`）再逐个落地，禁止"先写代码后补结构"。
8. **收尾即闭环**：`validate` **0 error 且覆盖类警告为 0**（见 §7 护栏）。

---

## 1. 初始全量生成流程（九步）

> 这是"导入一个项目就把它画全"的标准动作。**不要**只跑 `migrate` 就交付——
> `migrate` 给的是【待审】骨架（apis 全空），那只是第 0 步。

| 步 | 动作 | 要点 |
|---|---|---|
| 0 | `init` 或 `change-open` | 建结构目录 + 默认架构规则（`policy.yml`） |
| 1 | 确认范围 | 目标仓库、当前 revision、slug；多仓库 → 多棵树（各自 `parent: null`） |
| 2 | 顶层骨架 | 先写根（`source: []`、`repository` 填仓库 URL），再写 3–8 个一级子模块（**先广度**） |
| 3 | 逐层下钻 | 每层先 `list` 看当前层，再逐个展开；容器要拆就先 `promote` |
| 4 | 叶子收尾 | **从代码提取该叶子全部 API**，逐条写双语简介 |
| 5 | 箭头补全 | **从 import / 调用点提取出向 `deps`**；跨仓库调用 = 跨树箭头 |
| 6 | 证据落盘 | 每个模块写 `source` / `revision` / `fingerprint`（fingerprint 一律用 `refresh` 或 `fingerprint` 命令算） |
| 7 | 渲染数据同轮建立 | 每个**容器**用 `layout-upsert` 写 `order`/`groups`/`mode`/`reading` |
| 8 | 收尾 | `validate` 修到 0 error → `build --render` → 汇报路径 + 深链示例 |
| 9 | 汇报 | 返回 HTML / tree.json 精确路径、回执摘要、`#module=<id>` 深链 |

### 1.1 下钻要精细（最容易偷懒的地方）

- **叶子判据**：一个文件 / 一个类 / 一组内聚函数 / 一个 UI 组件 / 一条路由组。
  **只要还能说清"它内部由哪几块组成"，就继续拆。**
- **必须继续拆的信号**：`source` 覆盖 ≥3 个文件；单文件行跨度 ≥300；
  一个模块里混了 ≥2 个可独立命名的职责；`apis` ≥6 条且能按子功能分组。
- **目标深度**：小仓库 ≥3 层；中大型 ≥5–8 层；大仓库 8 层以上。**深度不设上限。**
- **不要停在"一层目录 = 一层模块"** —— 目录常常是粗粒度的，光看目录一定太粗。
- 容器升格：`promote` 之后再写子模块。

### 1.2 批量与批次

```sh
# 一次提交多模块（create 与 patch 混提），单批 ≤200 条，任一条不合法整批不落盘
R batch --dir ./archinorm-<slug> --repo /path/to/repo --items-file items.json

# items.json 里两种条目：
#   ① 完整模块对象                      → 等同 upsert
#   ② {"id":"某.id","patch":{字段...}}  → 等同 patch（可 patch 本批刚建的模块）
```

- **批内依赖自闭合，跨批依赖后补**（用 `patch` 或下一批）。
- 总量不设上限：**连续多批直到整棵树建完**，不要因为"已经写了几批"就收尾。

---

## 2. 伴随开发流程（先建树、再逐个模块完成）

架构树要**伴随工程生长**。任何"先写代码后补树"都会造成结构漂移。

```
0) init（新项目/空目录）
1) change-open   开变更（title / intent / modules{create,modify,delete} / acceptance）
2) brief         拿开发指引：契约、影响面、架构规则、验收清单
3) check         把拟建模块与拟加依赖先预检（parent 推导、深度、环、policy），不通过就改设计
4) batch/upsert  建计划态模块（state=planned、fingerprint=pending、source 可指向未落地文件）
                 容器同轮 layout-upsert 写该层渲染数据
5) ★ 写 API 与依赖箭头 —— 先全写 apis（只在叶子上），再写 deps（否则 to_api 校验失败）
6) refresh       每完成一个叶子：refresh --ids <id> --activate（源码未落地会拒绝激活）
7) change-close  收尾：刷新指纹 / 激活 planned / 0 error + 覆盖警告 0 强制 / 编译渲染
```

---

## 3. 渲染数据配方（人读性的另一半）

每个**容器**必须有一份 `renders/<id 点号换斜杠>.json`，否则 `layout/missing` 提醒。
字段：`mode`(auto/groups/layers/grid) · `max_columns`(1-6) · `order` · `groups` · `reading` · `edge_hints`

1. **顺序 = 数据流**：`order` 按"谁先产生、谁后消费"排；管道链用 `mode: layers`（箭头整体左→右）。
2. **分组 = 领域边界**：同一子系统的子模块放一组；每组 2–5 个。
3. **导语 = 阅读路径**：`reading` 一句话说明"从哪看起、箭头代表什么"。
4. **长边提示**：回指/跨整张图的边写 `edge_hints`（`lane` 2..4 拉开轨道）。
5. **不要硬凑分组**：一组平级功能就直接 `grid`。
6. **随结构同步**：增删改名子模块后，同轮更新该层 `order`/`groups`。

---

## 4. 增量再生成策略（核心）

**触发**：用户要求同步，或代码有变更。

1. `sync --repo <repo>` → 拿到脏子树 / 新增文件建议 / 失效 source / planned 进度。
2. **深到浅重建**：
   - **affected 叶子**：重读代码 → 增删 API、更新介绍；职责变大就 `promote` 后拆出子模块；
   - **affected 容器**：更新介绍与子级变化，**不重读全部代码**；
   - **祖先**：只复核 `name`/`description` 与统计；
   - **删模块**：source 全失效 → `delete`，并**按返回的 dangling_edges 修完所有指向它的 deps**
     （悬空边是 error，逃不掉）；
   - **跨树箭头**：两端都要查；目标树改了 API 键就要改 `to_api`。
3. **同步渲染数据**：新增/删除子模块后必须重写该层 `order`/`groups`/`reading`。
4. `refresh --ids ... ` 更新 `fingerprint`/`revision`/`updated_at` → `validate` → `build`。
5. **汇报**：新增/删除/拆分/改名模块与 API、增删边清单（标注跨树）、重排过的渲染数据层。

**铁律**：只重写受影响子树；不动无关模块；宁可分批多轮、拆得更细，也不可粗粒度合并或留脏数据。

---

## 5. 创作规范细节

- **id 命名**：从代码结构推导（目录/包/服务名转小写段）；同层唯一；段数不限（越精细越好）；
  不要数字开头；最后一段避免 `index`（会与容器 `index.md` 冲突）。
- **每叶 API 数量**：尽量 **3–5 条**（多了就再拆一层）。API 越少、箭头锚定越精确。
- **API 提取范围**：HTTP 路由（`METHOD /path`）、RPC 方法、Kafka topic、AMQP 队列、
  数据库表（`mysql:orders`）、Redis 键前缀、文件路径、WebSocket 端点。
  **键全局唯一**，重复会 error（合并或细化 path）。
  - **键怎么写**：http → `METHOD path`（如 `POST /pay/charge`，**不带 `http:` 前缀**）；
    非 http → `protocol:path`（如 `file:logs/x.jsonl`、`rpc:notify.send`、`ws:wss://...`）。
- **箭头提取**：只在能确认调用关系时才写 `deps`。`kind` 语义：`call`=同步调用、
  `event`=发布/订阅、`dataflow`=数据管道、`reference`=一般引用。不确定就 `reference` 或不写。
  - **两端都有 apis 时补 `from_api`/`to_api`** —— 箭头才会钉在具体接口那一行（否则 `dep/unanchored`）。
  - `from_api` 只能是**本模块自己**的 API 键；容器没有 apis，所以容器的箭头只能挂框边。
  - **API 键全局唯一**意味着：同一条真实路径只在**一个**模块里声明，其他模块用箭头引用它。
  - **依赖必须无环**（policy `core-acyclic`）；双向通道要拆成单向主链。
- **双语**：先写中文再译英文；术语保持一致（如"支付 / Payment"）。
- **YAML 子集**：frontmatter 只用普通标量、`{zh, en}` 内联映射、数组、`>` 折叠块；
  禁锚点/别名/`|` 块/TAB。优先用命令写入，让序列化器处理。
- **uid**：随机 8 位 hex，重命名/移动都**保留不变**。

---

## 6. 完整示例模块文件

`modules/demo/order/payment.md`（根 id = `demo`，这里是一个**叶子**）：

```markdown
---
uid: 8f3a9c2e
id: demo.order.payment
parent: demo.order
revision: 9f1a1cf0b6e9e2a3d4c5b6a7f8e9d0c1b2a3f4e5
updated_at: 2026-10-16T12:00:00Z
fingerprint: e3b0c44298fc1c149afbf4c8996fb924
state: active
source:
  - path: src/order/payment.ts
name:
  zh: 支付
  en: Payment
description:
  zh: >-
    对接支付渠道、处理异步回调、维护支付单状态机；幂等由渠道流水号保证。
  en: >-
    Talks to payment channels, handles async callbacks, maintains the payment
    state machine; idempotency keyed by channel transaction id.
apis:
  - protocol: http
    method: POST
    path: /pay/charge
    description:
      zh: 发起支付（幂等键 = 渠道流水号）
      en: create a charge (idempotency key = channel txn id)
  - protocol: http
    method: GET
    path: /pay/{id}
    description:
      zh: 查询支付单状态
      en: query payment status
  - protocol: mysql
    path: orders.payment
    description:
      zh: 支付单主表
      en: payment table
  - protocol: file
    path: logs/payment.jsonl
    description:
      zh: 支付流水日志（审计用）
      en: payment audit log
deps:
  - kind: call
    to: demo.order
    from_api: POST /pay/charge
    to_api: POST /orders/{id}/paid
    label:
      zh: 支付成功后回写订单
      en: mark order paid on success
  - kind: event
    to: demo.notify
    label:
      zh: 支付结果事件

# 支付

（正文可选：人读的补充说明、边界、坑。机器不读。）
```

> 注意这个例子里：**4 条 API 覆盖了 4 种协议**（http / mysql / file），
> **2 条箭头分别锚定到具体 API 行**，`description` 双语且写清了语义约束（幂等键）。

---

## 7. 常见诊断 → 修复对照

| 诊断码 | 含义 | 修法 |
|---|---|---|
| `structure/parent-mismatch` | parent ≠ id 去尾段 | 按 evidence.derived 改 parent |
| `structure/parent-not-exist` | 孤儿（父不存在） | 创建父模块或改 parent |
| `structure/file-id-mismatch` | 文件路径与 id 不一致 | 用 upsert 重写该模块（工具自动落位） |
| `structure/leaf-too-coarse` | 叶子过粗 | `promote` 后拆出子模块 |
| `structure/shallow-hierarchy` | 模块数多但层级过浅 | 继续下钻补中间层 |
| `api/leaf-missing` | 叶子缺 apis | 补 apis（**是接口清单，不是占位空数组**） |
| `api/leaf-empty` | 叶子 apis 为空数组 | 同上；迁移刚跑完的过渡态才允许 |
| `api/non-leaf` | 容器/根写了 apis | 下放到叶子并删掉本字段 |
| `api/key-duplicate` | API 键全局重复 | 只留一个定义，其他模块用箭头引用 |
| `api/protocol-invalid` / `api/method-invalid` | 协议/方法不合法 | http 须大写 method；非 http 禁 method |
| `dep/target-missing` | 悬空箭头 | 建目标模块或改/删箭头 |
| `dep/from-api-invalid` / `to-api-invalid` | 锚点不是本模块/目标的 API 键 | 用正确的 API 键（注意 http 键不带 `http:` 前缀） |
| `dep/unanchored` | 两端都有 API 却没写锚点 | 补 `from_api`/`to_api`，让箭头钉到 API 行 |
| `dep/self` / `dep/kind-invalid` | 自环 / kind 非法 | 改 to 或 kind（call/event/dataflow/reference） |
| `policy/core-acyclic` | 依赖成环 | 拆成单向主链（双向通道只保留一个方向） |
| `policy/<rule-id>` | 架构规则违规 | 改设计；规则确需调整用 `policy-upsert` 并说明理由 |
| `evidence/fingerprint-drift` | 数据过期 | `refresh --ids ...` 或 `sync` 计划增量重建 |
| `structure/planned-source-missing` | 计划态 source 未落地 | 实现文件后 `refresh --ids <id> --activate` |
| `refresh/activate-not-landed` | 请求激活但源码未落地 | 先实现 source 指向的文件（不允许假激活） |
| `layout/missing` | 容器缺渲染数据 | `layout-upsert` 补 order/groups/mode |
| `layout/order-child` / `group-child` | 引用了非直接子级 | 改成直接子模块 id |
| `change/create-not-landed` | close 时 create 仍有 planned | 实现并激活后再 close |
| `coverage/empty-apis` | **整库一条 API 都没有** | 逐个叶子补 API（图会是空壳） |
| `coverage/empty-deps` | **整库一条箭头都没有** | 补 deps（图上不会有箭头，动效无处可动） |

---

## 8. 护栏

- **规模不设上限**：不要因为"层级深"或"框太多"而合并模块；只有职责确实单一才停止下钻。
- **单批 ≤200**（`batch` 原子提交）；**总量与深度都不设上限**，鼓励 100–1000+ 模块的精细结构。
- **0 error 且覆盖警告 0**：`change-close` 与交付前 `build` 都要求 0 error；
  `coverage/empty-apis` / `coverage/empty-deps` 出现即视为**空壳**，不算做完。
- **计划态纪律**：planned 必须带 `fingerprint: pending`；实现后必须 `activate`，不允许长期悬挂。
- **规则先行**：新项目先确认 `policy.yml`；违规先改设计，禁止用删规则的方式绕过。
- **用户没要求时，不修改已通过校验的无关模块。**
- **渲染产物路径必须如实汇报**（不要用"已生成"代替真实路径）。
- **动效纪律（承 archify DESIGN.md）**：动效有明确归属、会结束、不承载「静帧里就消失」的语义；
  控件过渡 140–200ms；🔴 **绝不用动效暗示源数据里不存在的关系或活动** ——
  也就是说，**没有 `deps` 箭头就不该有任何流动**。空壳图自己「看起来在动」是一种欺骗，
  这正是 `coverage/empty-deps` 必须清零的原因。
